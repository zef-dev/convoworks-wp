<?php

namespace Convo\Wp\Http;

use function Convo\Wp\view;
class DashboardController extends \Convo\Wp\Http\Controller
{
    /**
     * Display the main dashboard page
     */
    public static function index()
    {
        $services = wp_remote_get(home_url() . '/wp-json/convo/v1/services');
        $services = \json_decode($services['body']);
        view('dashboard/index', ['services' => $services->data]);
    }
}
