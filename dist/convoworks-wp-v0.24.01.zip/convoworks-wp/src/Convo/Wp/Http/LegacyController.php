<?php

namespace Convo\Wp\Http;

use function Convo\Wp\view;
class LegacyController extends \Convo\Wp\Http\Controller
{
    /**
     * Display the main dashboard page
     */
    public static function index()
    {
        view('legacy/index');
    }
}
